package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Registration {
	WebDriver driver;
	By signUpButton = By.xpath("//a[@href='/sign-up']");
	By supplierButton = By.xpath("//div[text()='A Supplier']");
	By clientButton = By.xpath("//div[text()='A Client']");
	By nextButton = By.xpath("//span[text()='Next']");

	// page 1
	By username = By.xpath("//input[@formcontrolname='userId']");
	By password = By.xpath("//input[@formcontrolname='password']");
	By confirmPass = By.xpath("//input[@formcontrolname='confirm_password']");

	// page 2
	By firstName = By.id("mat-input-3");
	By lastName = By.id("mat-input-4");
	By email = By.id("mat-input-5");
	By mobile = By.id("mat-input-6");
	By address = By.id("mat-input-7");
	By city = By.id("mat-input-8");
	By state = By.id("mat-input-9");
	By province = By.id("mat-input-10");
	By country = By.id("mat-input-11");

	// page 3
	By accountNumber = By.xpath("//input[@formcontrolname='accountNumber']");
	By verifyCodeButton = By.xpath("//span[@class='mat-button-wrapper']//span[1]");

	public Registration(WebDriver driver) {
		this.driver = driver;
	}

	public void clickSignUpButton() {
		driver.findElement(signUpButton).click();
	}

	public void clickSupplier() {
		driver.findElement(supplierButton).click();
	}
	public void clickClient() {
		driver.findElement(clientButton).click();
	}

	public void clickNextButton() {
		driver.findElement(nextButton).click();
	}

	// page 1
	public void setUsername(String username) {
		driver.findElement(this.username).sendKeys(username);
	}

	public void setPassword(String password) {
		driver.findElement(this.password).sendKeys(password);
	}

	public void setConfirmPass(String confirmPass) {
		driver.findElement(this.confirmPass).sendKeys(confirmPass);
	}

	public void sendKeyPage1(String username, String password, String confirmPassword) {
		setUsername(username);
		setPassword(confirmPassword);
		setConfirmPass(confirmPassword);
		clickNextButton();
	}

	// page 2
	public void setFirstName(String firstName) {
		driver.findElement(this.firstName).sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		driver.findElement(this.lastName).sendKeys(lastName);
	}

	public void setEmail(String email) {
		driver.findElement(this.email).sendKeys(email);
	}

	public void setMobile(String mobile) {
		driver.findElement(this.mobile).sendKeys(mobile);
	}

	public void setAddress(String address) {
		driver.findElement(this.address).sendKeys(address);
	}

	public void setCity(String city) {
		driver.findElement(this.city).sendKeys(city);
	}

	public void setState(String state) {
		driver.findElement(this.state).sendKeys(state);
	}

	public void setProvince(String province) {
		driver.findElement(this.province).sendKeys(province);
	}

	public void setCountry(String country) {
		driver.findElement(this.country).sendKeys(country);
	}

	public void sendKeyPage2(String firstname, String lastname, String email, String mobile, String address,
			String city, String state, String province, String country) {
		setFirstName(firstname);
		setLastName(lastname);
		setEmail(email);
		setMobile(mobile);
		setAddress(address);
		setCity(city);
		setState(state);
		setProvince(province);
		setCountry(country);
		clickNextButton();
	}

	// page 3
	public void setAccountNumber(String accountNumber) {
		driver.findElement(this.accountNumber).sendKeys(accountNumber);
	}

	public void clickVerifyButton() {
		driver.findElement(verifyCodeButton).click();
	}

	public void sendKeyPage3(String accountNumber) {
		setAccountNumber(accountNumber);
		clickVerifyButton();
	}
}

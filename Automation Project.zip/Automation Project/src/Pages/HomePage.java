package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class HomePage {
	WebDriver driver;
	// login
	By button = By.linkText("Sign In");
	By username = By.xpath("//input[@label='username']");
	By password = By.xpath("//input[@label='password']");
	By signIn = By.xpath("//span[contains(.,'Sign In')]");

	// view
	By all = By.xpath("//span[text()=' All ']");
	By Approved = By.xpath("//span[text()=' Approved ']");
	By InReview = By.xpath("//span[text()=' In Review ']");
	By Rejected = By.xpath("//span[text()=' Rejected ']");
	By buttonView = By.xpath("//div[text()=' View Invoices ']");

	// search
	By invoiceNumber = By.name("invoiceNumber");
	By clientId = By.name("clientId");
	By supplierId = By.name("supplierId");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickLoginButton() {
		driver.findElement(this.button).click();

	}
	// login

	public void setUsername(String username) {
		driver.findElement(this.username).clear();
		driver.findElement(this.username).sendKeys(username);
	}

	public void setPassword(String password) {
		driver.findElement(this.password).clear();
		driver.findElement(this.password).sendKeys(password);
	}

	public void clickSignIn() {
		driver.findElement(this.signIn).click();
	}

	// view

	public void clickViewButton() {
		driver.findElement(this.buttonView).click();
	}

	public void clickViewAll() {
		this.clickViewButton();
		driver.findElement(this.all).click();
	}

	public void clickViewApproved() {
		this.clickViewButton();
		driver.findElement(this.Approved).click();
	}

	public void clickViewInReview() {
		this.clickViewButton();
		driver.findElement(this.InReview).click();
	}

	public void clickViewRejected() {
		this.clickViewButton();
		driver.findElement(this.Rejected).click();
	}

	// search
	public void setInvoice(String invoiceNumber) {
		driver.findElement(this.invoiceNumber).sendKeys(invoiceNumber, Keys.ENTER);
	}

	public void setClientCode(String clientId) {
		driver.findElement(this.clientId).sendKeys(clientId, Keys.ENTER);

	}

	public void setSupplierCode(String supplierId) {
		driver.findElement(this.supplierId).sendKeys(supplierId, Keys.ENTER);

	}

	// Login
	public void LoginToSHS(String username, String password, String message, String id) {
		this.setUsername(username);
		this.setPassword(password);
		this.clickSignIn();
	}
	public void sendkeysLogin(String username, String password) {
		this.setUsername(username);
		this.setPassword(password);
		this.clickSignIn();
	}

	// Search
	public void SearchInSHS(String invoiceNumber, String clientId, String supplierId, String result, String id) {
		this.clickViewButton();
		this.setInvoice(invoiceNumber);
		this.setClientCode(clientId);
		this.setSupplierCode(supplierId);
	}

}

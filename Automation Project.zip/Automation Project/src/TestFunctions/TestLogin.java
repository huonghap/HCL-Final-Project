package TestFunctions;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Pages.HomePage;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterClass;
import XLSReader.XLSReader;

public class TestLogin {
	WebDriver driver;

	HomePage homeObj;
	String baseUrl = "http://54.237.43.64/";
	static ExtentTest test;
	static ExtentReports report;

		/**
		 * This function will execute before each Test tag in testng.xml
		 * 
		 * @param browser
		 * @throws Exception
		 */
		@BeforeTest
		@Parameters("browser")
		public void setup(String browser) throws Exception {
			// Check if parameter passed from TestNG is 'firefox'
			if (browser.equalsIgnoreCase("firefox")) {
				System.setProperty("webdriver.gecko.driver", "E:\\testerApp\\geckodriver.exe");
				driver = new FirefoxDriver();

			}
			if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "E:\\testerApp\\chromedriver.exe");
				driver = new ChromeDriver();
			}

			else if (browser.equalsIgnoreCase("Edge")) {
				System.setProperty("webdriver.edge.driver", "E:\\testerApp\\msedgedriver.exe");
				driver = new EdgeDriver();
			} else {
				// If no browser passed throw exception
				throw new Exception("Browser is not correct");
			}
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}

		@Test(dataProvider = "LoginData")
		public void testLogin(String username, String password, String message, String id) {
			driver.get(baseUrl);
			homeObj = new HomePage(driver);
			homeObj.clickLoginButton();

			homeObj.LoginToSHS(username, password, message, id);

			String text = "";
			if (!driver.findElements(By.xpath("//h1[text()='Dashboard']")).isEmpty())
				text = driver.findElement(By.xpath("//h1[text()='Dashboard']")).getText();

			if (driver.findElements(By.tagName("mat-label")).isEmpty()) {
				driver.findElement(By.xpath("//div/div/app-user-info-container/div/div[3]/button/span/mat-icon"))
						.click();
				if (text.equals("Dashboard"))
					test.log(LogStatus.PASS, id + ": passed");
				else
					test.log(LogStatus.FAIL, id + ": failed");

			} else {
				if (message.contains("    ")) {
					String error[] = message.split("    ");
					if (error[0].equals(driver.findElement(By.tagName("mat-label")).getText())) {
						test.log(LogStatus.PASS, id + ".1: passed");
					}

					for (int i = 1; i < error.length; i++) {
						if (error[i].contains(driver.findElement(By.xpath("(//mat-error)[" + i + "]")).getText())) {

							// assertTrue(error[i].contains(driver.findElement(By.xpath("(//mat-error)[" + i
							// + "]")).getText()));
							test.log(LogStatus.PASS, id + "." + (i + 1) + ": passed");
						} else {
							test.log(LogStatus.FAIL, id + "." + (i + 1) + ": failed");
						}
					}
				} else if (message.equals(driver.findElement(By.tagName("mat-label")).getText())) {
					test.log(LogStatus.PASS, id + ": passed");
				} else
					test.log(LogStatus.FAIL, id + ": failed");
			}
		}

		@DataProvider(name = "LoginData")
		public String[][] getData() {
			String[][] rowCol = null;
			try {
				XLSReader reader = new XLSReader("D:\\HCL Test\\BankData.xlsx");
				String sheetName = "Login";

				int noOfRow = reader.getRowCount(sheetName);
				int noOfCell = reader.getCellCount(sheetName, 0);
				rowCol = new String[noOfRow][noOfCell];

				for (int i = 1; i <= noOfRow; i++) {
					for (int j = 0; j < noOfCell; j++) {
						rowCol[i - 1][j] = reader.getCellData(sheetName, i, j);
					}
				}

			} catch (Exception e) {
				System.out.println(e);
			}
			return rowCol;
		}

		@BeforeClass
		public void beforeClass() {

			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			// driver.get(baseUrl);
			report = new ExtentReports(System.getProperty("user.dir") + "/test-output/TestLogin_Results.html");
			test = report.startTest("Login Test");
		}

		@AfterClass
		public void afterClass() {
			driver.quit();
			report.endTest(test);
			report.flush();
		}

	}


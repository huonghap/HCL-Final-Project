package TestFunctions;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Pages.HomePage;

import XLSReader.XLSReader;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class TestSearch {
	WebDriver driver;

	HomePage homeObj;

	String baseUrl = "http://54.237.43.64/";
	static ExtentTest test;
	static ExtentReports report;

	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception {
		// Check if parameter passed from TestNG is 'firefox'
		if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "E:\\testerApp\\geckodriver.exe");
			driver = new FirefoxDriver();

		}
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "E:\\testerApp\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", "E:\\testerApp\\msedgedriver.exe");
			driver = new EdgeDriver();
		} else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(dataProvider = "Search")
	public void testSearch(String invoiceNumber, String clientId, String supplierId, String result, String id)
			throws InterruptedException {

		homeObj.SearchInSHS(invoiceNumber, clientId, supplierId, result, id);
		try {
			if (!invoiceNumber.isBlank())
				driver.findElement(By.name("invoiceNumber")).sendKeys(invoiceNumber, Keys.ENTER);
			else if (!clientId.isBlank())
				driver.findElement(By.name("clientId")).sendKeys(clientId, Keys.ENTER);
			else
				driver.findElement(By.name("supplierId")).sendKeys(supplierId, Keys.ENTER);
			Thread.sleep(500);

			boolean resultPresent = driver.findElement(By.xpath("//td[contains(@class,'mat-cell cdk-cell')]"))
					.isDisplayed();
			if (resultPresent) {
				String code = driver.findElement(By.xpath("//td[contains(@class,'mat-cell cdk-cell')]")).getText();
				if (code.contains(result)) {
					test.log(LogStatus.PASS, id + ": Passed");
				} else {
					test.log(LogStatus.FAIL, id + ": Failed1");
				}
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			if (result.isBlank())
				test.log(LogStatus.PASS, id + ": Passed");
			else
				test.log(LogStatus.FAIL, id + ": Failed");
		}
	}

	@DataProvider(name = "Search")
	public String[][] getData() {
		String[][] rowCol = null;
		try {
			XLSReader reader = new XLSReader("D:\\HCL Test\\BankData.xlsx");
			String sheetName = "Search";

			int noOfRow = reader.getRowCount(sheetName);
			int noOfCell = reader.getCellCount(sheetName, 0);
			rowCol = new String[noOfRow][noOfCell];

			for (int i = 1; i <= noOfRow; i++) {
				for (int j = 0; j < noOfCell; j++) {
					rowCol[i - 1][j] = reader.getCellData(sheetName, i, j);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return rowCol;
	}

	@BeforeClass
	public void beforeClass() {

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		report = new ExtentReports(System.getProperty("user.dir") + "/test-output/TestSearch_Results.html");
		test = report.startTest("Search Test");

		driver.get(baseUrl);
		homeObj = new HomePage(driver);
		homeObj.clickLoginButton();
		homeObj.sendkeysLogin("banker1", "password");
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
		report.endTest(test);
		report.flush();
	}

}

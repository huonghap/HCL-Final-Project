package TestFunctions;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import Pages.HomePage;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class TestView {
	WebDriver driver;

	HomePage homeObj;

	String baseUrl = "http://54.237.43.64/";
	static ExtentTest test;
	static ExtentReports report;

	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception {
		// Check if parameter passed from TestNG is 'firefox'
		if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "E:\\testerApp\\geckodriver.exe");
			driver = new FirefoxDriver();

		}
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "E:\\testerApp\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", "E:\\testerApp\\msedgedriver.exe");
			driver = new EdgeDriver();
		} else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void All() {
		homeObj = new HomePage(driver);
		homeObj.clickViewAll();
		String text = driver.findElement(By.xpath("//td[text()='123123']")).getText();
		assertEquals(text, "123123");
		test.log(LogStatus.PASS, "Navigate to All page.");
	}

	@Test
	public void Approved() {

		homeObj = new HomePage(driver);
		homeObj.clickViewApproved();
		String code = driver.findElement(By.xpath("//td[contains(@class,'mat-cell cdk-cell')]")).getText();
		System.out.println(code);
		assertEquals(code, "11");
		test.log(LogStatus.PASS, "Navigate to Approved page.");

	}

	@Test
	public void InReview() {

		homeObj = new HomePage(driver);
		homeObj.clickViewInReview();
		driver.findElement(By.className("mat-paginator-container")).isDisplayed();
		test.log(LogStatus.PASS, "Navigate to InReview page.");

	}

	@Test
	public void Rejected() {
		homeObj = new HomePage(driver);
		homeObj.clickViewRejected();
		driver.findElement(By.className("mat-paginator-container")).isDisplayed();
		test.log(LogStatus.PASS, "Navigate to Rejected page.");
	}

	@BeforeClass
	public void beforeClass() {
		
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.get(baseUrl);
		report = new ExtentReports(System.getProperty("user.dir") + "/test-output/TestView_Results.html");
		test = report.startTest("Search Test");
		homeObj = new HomePage(driver);
		homeObj.clickLoginButton();
		homeObj = new HomePage(driver);
		homeObj.sendkeysLogin("banker1", "password");
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
		report.endTest(test);
		report.flush();
	}

}

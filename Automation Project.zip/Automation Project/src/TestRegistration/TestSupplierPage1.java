package TestRegistration;

import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Pages.Registration;
import XLSReader.XLSReader;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class TestSupplierPage1 {
	private WebDriver driver;
	private static String baseUrl = "http://54.237.43.64/";
	static ExtentTest test;
	static ExtentReports report;
	Registration supplierReg;

	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception {
		// Check if parameter passed from TestNG is 'firefox'
		if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "E:\\testerApp\\geckodriver.exe");
			driver = new FirefoxDriver();

		}
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "E:\\testerApp\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", "E:\\testerApp\\msedgedriver.exe");
			driver = new EdgeDriver();
		} else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(dataProvider = "DataRegister")
	public void page1(String username, String password, String confirmPassword, String message, String TC_id)
			throws InterruptedException {
		supplierReg = new Registration(driver);
		supplierReg.clickSignUpButton();
		supplierReg.clickSupplier();
		supplierReg.sendKeyPage1(username, password, confirmPassword);
		Thread.sleep(1000);

		if (!driver.findElements(By.xpath("//mat-error[@role='alert']")).isEmpty()) {
			if (message.contains("    ")) {
				String error[] = message.split("    ");
				for (int i = 0; i < error.length; i++) {
					if (error[i].contains(
							driver.findElement(By.xpath("(//mat-error[@role='alert'])[" + (i + 1) + "]")).getText()))
						test.log(LogStatus.PASS, TC_id + ": PASS");
					else
						test.log(LogStatus.FAIL, TC_id + ": FAIL");
				}

			} else {
				if (message.equals(driver.findElement(By.xpath("//mat-error[@role='alert']")).getText()))
					test.log(LogStatus.PASS, TC_id + ": PASS");
				else
					test.log(LogStatus.PASS, TC_id + ": PASS");
			}
		} else {
			String color = driver.findElement(By.xpath("//div[text()='Personal Details']")).getCssValue("color");
			if (message.equals(color))
				test.log(LogStatus.PASS, TC_id + ": PASS");
			else
				test.log(LogStatus.PASS, TC_id + ": PASS");
		}
	}

	@DataProvider(name = "DataRegister")
	public String[][] getData() {
		String[][] rowCol = null;
		try {
			XLSReader reader = new XLSReader("D:\\HCL Test\\BankData.xlsx");
			String sheetName = "SupplierPage1";

			int noOfRow = reader.getRowCount(sheetName);
			int noOfCell = reader.getCellCount(sheetName, 0);
			rowCol = new String[noOfRow][noOfCell];

			for (int i = 1; i <= noOfRow; i++) {
				for (int j = 0; j < noOfCell; j++) {
					rowCol[i - 1][j] = reader.getCellData(sheetName, i, j);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return rowCol;
	}

	@BeforeClass
	public void beforeMethod() {
		
		driver.get(baseUrl);
		report = new ExtentReports(System.getProperty("user.dir") + "/test-output/TestSupplierPage1_Result.html");
		test = report.startTest("Supplier Registration Page 1");
	}

	@AfterClass
	public void afterMethod() {

		report.endTest(test);
		report.flush();
		driver.quit();
	}

}

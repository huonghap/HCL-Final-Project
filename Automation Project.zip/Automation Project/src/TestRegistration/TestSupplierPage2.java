package TestRegistration;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Pages.Registration;
import XLSReader.XLSReader;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.edge.EdgeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;

public class TestSupplierPage2 {
	private WebDriver driver;
	private static String baseUrl = "http://54.237.43.64/sign-up/supplier";
	static ExtentTest test;
	static ExtentReports report;
	Registration supplierReg;

	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception {
		// Check if parameter passed from TestNG is 'firefox'
		if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "E:\\testerApp\\geckodriver.exe");
			driver = new FirefoxDriver();

		}
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "E:\\testerApp\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver", "E:\\testerApp\\msedgedriver.exe");
			driver = new EdgeDriver();
		} else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(dataProvider = "Page2Data")
	public void TestPage2(String firstname, String lastname, String email, String mobile, String address, String city,
			String state, String province, String country, String message, String TC_id) {
		driver.get(baseUrl);
		supplierReg = new Registration(driver);
		
		//page 1
		supplierReg.sendKeyPage1("huong", "123123", "123123");
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

		// page2
		supplierReg.sendKeyPage2(firstname, lastname, email, mobile, address, city, state, province, country);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		if (!driver.findElements(By.xpath("//mat-error[@role='alert']")).isEmpty()) {
			if (message.contains("   ")) {
				String error[] = message.split("   ");
				for (int i = 0; i < error.length; i++) {
					if (error[i].contains(
							driver.findElement(By.xpath("//mat-error[text()=' " + error[i] + " ']")).getText()))
						test.log(LogStatus.PASS, "Test " + TC_id + " passed");
					else
						test.log(LogStatus.FAIL, "Test " + TC_id + " failed.");
				}
			} else {
				if (message.contains(driver.findElement(By.xpath("//mat-error[@role='alert']")).getText()))
					test.log(LogStatus.PASS, "Test " + TC_id + " passed");
				else
					test.log(LogStatus.FAIL, "Test " + TC_id + " failed");
			}
		} else {
			String color = driver.findElement(By.xpath("//div[text()='Bank Details']")).getCssValue("color");
			if (message.equals(color))
				test.log(LogStatus.PASS, "Test " + TC_id + " passed");
			else
				test.log(LogStatus.FAIL, "Test " + TC_id + " failed");
		}
	}

	@DataProvider(name = "Page2Data")
	public String[][] getData() {
		String[][] rowCol = null;
		try {
			XLSReader reader = new XLSReader("D:\\HCL Test\\BankData.xlsx");
			String sheetName = "SupplierPage2";

			int noOfRow = reader.getRowCount(sheetName);
			int noOfCell = reader.getCellCount(sheetName, 0);
			rowCol = new String[noOfRow][noOfCell];

			for (int i = 1; i <= noOfRow; i++) {
				for (int j = 0; j < noOfCell; j++) {
					rowCol[i - 1][j] = reader.getCellData(sheetName, i, j);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return rowCol;
	}

	@AfterMethod
	public void afterMethod(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(LogStatus.FAIL, "Test Case Failed");
		}

	}

	@BeforeClass
	public void beforeClass() {
		
		report = new ExtentReports(System.getProperty("user.dir") + "/test-output/TestSupplierPage2_Result.html");
		test = report.startTest("Supplier Registration Page 2");
	}

	@AfterClass
	public void afterClass() {

		report.endTest(test);
		report.flush();
		driver.quit();
	}

}
